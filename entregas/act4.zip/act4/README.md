# 1. Para levantar el servidor con el json, ejecutar:
npm i
npm run dev